#include <stdio.h>
#include <cstdio>
#include <iostream>
#include "House.h"

void main() 
{
	std::cout << "Test";


	House h;
	Sim s(h);

}