#pragma once
#include "Common.h"


class Robot
{


};

