#pragma once
#include "Common.h"
#include "HouseInterface.h"

class House : public HouseInterface
{
public:
	House(std::string path);
};

