#pragma once
class HouseInterface
{
	HouseInterface();
public:
	bool isClean()=0;
	bool isWall(Direction d)=0;
	bool isDirty()=0;
	void moveRobot(Direction d)=0;

};

