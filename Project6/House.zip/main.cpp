#include <iostream>
#include "House.h"

void main() 
{
	std::cout << "Test";
	House h("C:\/Users/\jonat/\source/\repos/\Project6/\Project6/\House1.txt");
}