#include <iostream>
#include "House.h"
#include <iostream>
#include <fstream>
#include <string>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>

using namespace std;

House::House(const char* path)
{
    string line;
    ifstream myfile(path);
    if (myfile.is_open())
    {
		getline(myfile, line);
		std::stringstream ss(line);
		std::string token;
		std::getline(ss, line);//desc
		std::getline(ss, line);//max_step
		m_maxStep = stoi(line);
		std::getline(ss, line, ',');
		m_rows = stoi(line);
		std::getline(ss, line);
		m_cols= stoi(line);

		cout << m_maxStep << " " << m_cols << " " << m_rows << " " << endl;

/*
		std::getline(ss, m_desc, ' ');


            while (getline(myfile, line))
            {
                cout << line << '\n';
            }
            myfile.close();
        }

        else cout << "Unable to open file";

        return 0;
		*/
    }
}

bool House::isClean()
{
	return true;
}

bool House::isWall(Direction d)
{
	return true;
}
bool House::isDirty()
{
	return true;
}
void House::moveRobot(Direction d)
{

}

