#pragma once
#include "Common.h"
#include "HouseInterface.h"
#include <vector>

class House : public HouseInterface
{
public:
	House(const char* path);
	bool isClean();
	bool isWall(Direction d);
	bool isDirty();
	void moveRobot(Direction d);


private:
	std::vector<char> m_origMapping;
	int m_rows, m_cols,m_maxStep;
};

